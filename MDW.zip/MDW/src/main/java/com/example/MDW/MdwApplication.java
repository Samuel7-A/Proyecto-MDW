package com.example.MDW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdwApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdwApplication.class, args);
	}

}
